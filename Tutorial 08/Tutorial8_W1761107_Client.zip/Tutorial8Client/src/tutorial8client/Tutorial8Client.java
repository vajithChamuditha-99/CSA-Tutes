/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tutorial8client;

import server.Exception_Exception;
import server.TemperatureSample;

/**
 *
 * @author User
 */
public class Tutorial8Client {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Tutorial8Client client = new Tutorial8Client();
        client.execute();
    }
    
    private void execute(){
        System.out.println("[Client] - Strating Test...");
        if(isConnected()){
            System.out.println("[Client] - Server is connected. continuing test...");
            TemperatureSample s = new TemperatureSample();
            s.setValue(2.1);
            try{
                addSample(s);
                System.out.println("[CLIENT] - Server has " + getNumberOfSamples() + " samples");
                System.out.println("[CLIENT] - Maximum saple in the server is  " + getMaximum().getValue());
            }catch(Exception_Exception e){
                System.out.println("[CLIENT] -" + e.getMessage());
            }
            s.setValue(-0.1);
            try{
                addSample(s);
                System.out.println("[CLIENT] - Server has " + getNumberOfSamples() + " samples");
                System.out.println("[CLIENT] - Maximum saple in the server is  " + getMaximum().getValue());
            }catch(Exception_Exception e){
                System.out.println("[CLIENT] -" + e.getMessage());
            }
            s.setValue(1.2);
            try{
                addSample(s);
                System.out.println("[CLIENT] - Server has " + getNumberOfSamples() + " samples");
                System.out.println("[CLIENT] - Maximum saple in the server is  " + getMaximum().getValue());
            }catch(Exception_Exception e){
                System.out.println("[CLIENT] -" + e.getMessage());
            }
        }else{
            System.out.println("[Client] - Server is not connected. Test failed !");
        }
        System.out.println("[Client] - Test Completed");
    }

    private static Boolean isConnected() {
        server.Tutorial8WebService_Service service = new server.Tutorial8WebService_Service();
        server.Tutorial8WebService port = service.getTutorial8WebServicePort();
        return port.isConnected();
    }

    private static Boolean addSample(server.TemperatureSample sample) throws Exception_Exception {
        server.Tutorial8WebService_Service service = new server.Tutorial8WebService_Service();
        server.Tutorial8WebService port = service.getTutorial8WebServicePort();
        return port.addSample(sample);
    }

    private static Integer getNumberOfSamples() {
        server.Tutorial8WebService_Service service = new server.Tutorial8WebService_Service();
        server.Tutorial8WebService port = service.getTutorial8WebServicePort();
        return port.getNumberOfSamples();
    }

    private static TemperatureSample getMaximum() throws Exception_Exception {
        server.Tutorial8WebService_Service service = new server.Tutorial8WebService_Service();
        server.Tutorial8WebService port = service.getTutorial8WebServicePort();
        return port.getMaximum();
    }

   
    
    
}
